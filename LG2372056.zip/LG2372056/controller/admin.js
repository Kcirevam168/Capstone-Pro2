const service = require('./admin.service');

exports.createUser = async (req, res) => {
  try {
    const { name, email, password, roleId } = req.body;
    await service.createUser(name, email, password, roleId);
    res.status(201).json({ message: 'User berhasil ditambahkan' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.updateUser = async (req, res) => {
  try {
    const { id } = req.params;
    const { name, email, roleId } = req.body;
    await service.updateUser(id, name, email, roleId);
    res.status(200).json({ message: 'User berhasil diupdate' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.deleteUser = async (req, res) => {
  try {
    const { id } = req.params;
    await service.deleteUser(id);
    res.status(200).json({ message: 'User berhasil dihapus' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};