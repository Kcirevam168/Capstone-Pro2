const service = require('./presensi.service');

exports.presensiPeserta = async (req, res) => {
  try {
    const { registrasiId } = req.params;
    await service.updateStatusHadir(registrasiId);
    res.status(200).json({ message: 'Presensi berhasil dicatat' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.uploadSertifikat = async (req, res) => {
  try {
    const { registrasiId } = req.params;
    const { linkSertifikat } = req.body;

    const success = await service.uploadSertifikatIfHadir(registrasiId, linkSertifikat);
    if (!success) return res.status(400).json({ message: 'Peserta belum hadir, sertifikat tidak bisa diupload' });

    res.status(200).json({ message: 'Sertifikat berhasil diupload' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
