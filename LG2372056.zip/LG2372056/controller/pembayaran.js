const service = require('./pembayaran.service');

exports.uploadBuktiPembayaran = async (req, res) => {
  try {
    const { registrasiId } = req.params;
    const { linkBukti } = req.body;

    await service.uploadBukti(registrasiId, linkBukti);
    res.status(200).json({ message: 'Bukti pembayaran berhasil diupload' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};