// FILE: components/UploadPaymentProof.js
function UploadPaymentProof({ registrationId }) {
    const [file, setFile] = useState(null);

    const handleSubmit = async (e) => {
        e.preventDefault();
        const formData = new FormData();
        formData.append('proof', file);

        try {
            const response = await fetch(`/api/upload-payment-proof/${registrationId}`, {
                method: 'POST',
                body: formData,
                headers: {
                    Authorization: `Bearer ${localStorage.getItem('token')}`,
                },
            });
            const data = await response.json();
            alert(data.message || data.error);
        } catch (error) {
            console.error('Error uploading payment proof:', error);
        }
    };

    return (
        <form onSubmit={handleSubmit}>
            <input type="file" accept="image/*,.pdf" onChange={(e) => setFile(e.target.files[0])} />
            <button type="submit">Upload Bukti Pembayaran</button>
        </form>
    );
}
