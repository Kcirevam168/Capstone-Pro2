const multer = require('multer');
const path = require('path');

const storage = multer.diskStorage({
  destination: './uploads/bukti_transfer',
  filename: (req, file, cb) => {
    cb(null, `transfer_${Date.now()}${path.extname(file.originalname)}`);
  }
});
const upload = multer({ storage });

app.post('/api/upload-bukti/:eventId', authenticateToken, upload.single('bukti'), async (req, res) => {
    const { eventId } = req.params;
    const buktiUrl = `/uploads/bukti_transfer/${req.file.filename}`;
    const userId = req.user.id;

    await db.query('UPDATE event_registrations SET bukti_transfer = ?, status_pembayaran = ? WHERE user_id = ? AND event_id = ?', [buktiUrl, 'pending', userId, eventId]);

    res.json({ message: 'Bukti transfer berhasil diupload.', link: buktiUrl });
});

app.post('/api/verifikasi-pembayaran', authenticateToken, async (req, res) => {
    const { user_id, event_id } = req.body;

    // Pastikan user adalah tim keuangan → tambahkan pengecekan role di `req.user.role`

    await db.query('UPDATE event_registrations SET status_pembayaran = "verified" WHERE user_id = ? AND event_id = ?', [user_id, event_id]);

    res.json({ message: 'Status pembayaran berhasil diverifikasi.' });
});

app.post('/api/scan-kehadiran', authenticateToken, async (req, res) => {
    const { qr_code_data } = req.body;
    const sertifikatUrl = `/uploads/sertifikat/sertifikat_${Date.now()}.pdf`; // Simulasi nama file sertifikat

    // Cari berdasarkan QR
    const [result] = await db.query('SELECT * FROM event_registrations WHERE qr_code_data = ?', [qr_code_data]);

    if (result.length === 0) {
        return res.status(404).json({ error: 'QR tidak ditemukan' });
    }

    await db.query('UPDATE event_registrations SET status = "hadir", sertifikat = ? WHERE qr_code_data = ?', [sertifikatUrl, qr_code_data]);

    res.json({ message: 'Presensi berhasil dicatat dan sertifikat disiapkan.', sertifikat: sertifikatUrl });
});

function authorizeRole(roleName) {
    return (req, res, next) => {
        if (req.user.role !== roleName) return res.sendStatus(403);
        next();
    };
}