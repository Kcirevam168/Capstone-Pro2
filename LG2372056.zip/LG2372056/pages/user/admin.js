const db = require('../../db');

exports.createUser = async (name, email, password, roleId) => {
  await db.execute(
    `INSERT INTO user (name, email, password, created_at, updated_at) VALUES (?, ?, ?, NOW(), NOW())`,
    [name, email, password]
  );
  const [[{ id }]] = await db.execute(`SELECT LAST_INSERT_ID() as id`);
  await db.execute(`INSERT INTO user_role (user_id, role_id) VALUES (?, ?)`, [id.id, roleId]);
};

exports.updateUser = async (id, name, email, roleId) => {
  await db.execute(
    `UPDATE user SET name = ?, email = ?, updated_at = NOW() WHERE id = ?`,
    [name, email, id]
  );
  await db.execute(`UPDATE user_role SET role_id = ? WHERE user_id = ?`, [roleId, id]);
};

exports.deleteUser = async (id) => {
  await db.execute(`DELETE FROM user_role WHERE user_id = ?`, [id]);
  await db.execute(`DELETE FROM user WHERE id = ?`, [id]);
};