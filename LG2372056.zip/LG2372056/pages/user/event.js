const mongoose = require('mongoose');

const eventSchema = new mongoose.Schema({
  name: String,
  waktu: Date,
  durasi: String,
  lokasi: String,
  narasumber: String,
  poster: String, // link ke file gambar
  biaya_registrasi: Number,
  max_peserta: Number,
  created_at: { type: Date, default: Date.now },
  updated_at: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Event', eventSchema);