const mongoose = require('mongoose');

const eventRegistrasiSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  event: { type: mongoose.Schema.Types.ObjectId, ref: 'Event' },
  qr_code: String, // link ke file qr
  status_pembayaran: { type: String, enum: ['pending', 'verified'], default: 'pending' },
  bukti_transfer: String, // link file
  status: { type: String, enum: ['hadir', 'tidak_hadir'], default: 'tidak_hadir' },
  sertifikat: String, // link file
  created_at: { type: Date, default: Date.now }
});

module.exports = mongoose.model('EventRegistrasi', eventRegistrasiSchema);
const [count] = await db.query('SELECT COUNT(*) as total FROM event_registrations WHERE event_id = ?', [eventId]);
const [event] = await db.query('SELECT max_peserta FROM events WHERE id = ?', [eventId]);

if (count[0].total >= event[0].max_peserta) {
    return res.status(400).json({ error: 'Kuota peserta penuh.' });
}