const db = require('../../db');

exports.updateStatusHadir = async (id) => {
  await db.execute(`UPDATE event_registrasi SET status = 'hadir' WHERE id = ?`, [id]);
};

exports.uploadSertifikatIfHadir = async (id, link) => {
  const [[check]] = await db.execute(`SELECT status FROM event_registrasi WHERE id = ?`, [id]);
  if (check.status !== 'hadir') return false;

  await db.execute(`UPDATE event_registrasi SET sertifikat = ? WHERE id = ?`, [link, id]);
  return true;
};
