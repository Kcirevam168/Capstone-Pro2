const db = require('../../db');

exports.uploadBukti = async (id, link) => {
  const [result] = await db.execute(
    `UPDATE event_registrasi SET bukti_transfer = ?, status_pembayaran = 'sudah' WHERE id = ?`,
    [link, id]
  );
  return result;
};