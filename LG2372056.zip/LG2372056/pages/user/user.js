function GuestRegistrationForm() {
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await fetch('/api/register-member', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name, email, password })
            });
            const data = await response.json();
            if (response.ok) {
                alert(data.message);
                // Redirect ke halaman login atau daftar event
            } else {
                alert(data.error);
            }
        } catch (error) {
            console.error('Error:', error);
            alert('Terjadi kesalahan saat registrasi.');
        }
    };

    return (
        <form onSubmit={handleSubmit}>
            <input type="text" value={name} onChange={(e) => setName(e.target.value)} placeholder="Nama Lengkap" />
            <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" />
            <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Password" />
            <button type="submit">Daftar Sekarang</button>
        </form>
    );
}

// FILE: components/EventList.js (untuk Guest & Member)
function EventList({ userRole }) {
    const [events, setEvents] = useState([]);

    useEffect(() => {
        const fetchEvents = async () => {
            try {
                const response = await fetch('/api/events'); // Endpoint untuk semua event
                const data = await response.json();
                if (response.ok) {
                    setEvents(data.events);
                }
            } catch (error) {
                console.error('Error fetching events:', error);
            }
        };
        fetchEvents();
    }, []);

    return (
        <div>
            <h2>Daftar Event</h2>
            {events.map(event => (
                <div key={event.id}>
                    <h3>{event.event_name}</h3>
                    <p>Tanggal: {event.event_date}</p>
                    <p>Lokasi: {event.location}</p>
                    <p>Biaya: Rp {event.registration_fee}</p>
                    {userRole === 'Member' && (
                        <button onClick={() => registerForEvent(event.id)}>Daftar Event Ini</button>
                    )}
                </div>
            ))}
        </div>
    );
}

// --- PSEUDO-CODE: BACKEND (dengan asumsi Node.js + Express) ---

// FILE: server.js (Contoh Sederhana)
const express = require('express');
const bodyParser = require('body-parser');
const bcrypt = require('bcrypt'); // Untuk hashing password
const jwt = require('jsonwebtoken'); // Untuk otentikasi
const db = require('./database'); // Asumsi ada modul koneksi database

const app = express();
app.use(bodyParser.json());

// Endpoint untuk registrasi member (Guest)
app.post('/api/register-member', async (req, res) => {
    const { name, email, password } = req.body;
    try {
        const hashedPassword = await bcrypt.hash(password, 10);
        // Asumsi role_id untuk Member adalah 2
        await db.query('INSERT INTO users (username, email, password_hash, role_id, is_active) VALUES (?, ?, ?, ?, TRUE)', [name, email, hashedPassword, 2]);
        res.status(201).json({ message: 'Registrasi member berhasil!' });
    } catch (error) {
        console.error('Error during member registration:', error);
        res.status(500).json({ error: 'Registrasi gagal. Email mungkin sudah terdaftar.' });
    }
});

// Endpoint untuk mendapatkan daftar event (Guest & Member)
app.get('/api/events', async (req, res) => {
    try {
        const [rows] = await db.query('SELECT id, event_name, event_date, location, registration_fee, poster_url FROM events WHERE status = "Active"');
        res.status(200).json({ events: rows });
    } catch (error) {
        console.error('Error fetching events:', error);
        res.status(500).json({ error: 'Gagal mengambil data event.' });
    }
});

// Endpoint untuk registrasi event oleh Member (membutuhkan autentikasi)
app.post('/api/event-register/:eventId', authenticateToken, async (req, res) => {
    const userId = req.user.id; // Didapat dari token
    const eventId = req.params.eventId;
    try {
        // Cek apakah member sudah terdaftar di event ini
        const [existing] = await db.query('SELECT * FROM event_registrations WHERE user_id = ? AND event_id = ?', [userId, eventId]);
        if (existing.length > 0) {
            return res.status(400).json({ error: 'Anda sudah terdaftar di event ini.' });
        }
        // Insert ke tabel event_registrations
        const qrCodeData = `EVTREG-${userId}-${eventId}-${Date.now()}`; // Contoh data QR
        await db.query('INSERT INTO event_registrations (user_id, event_id, registration_date, payment_status, attendance_status, qr_code_data) VALUES (?, ?, NOW(), "Pending", "Not Attended", ?)', [userId, eventId, qrCodeData]);
        res.status(201).json({ message: 'Berhasil mendaftar event. Silakan lakukan pembayaran.' });
    } catch (error) {
        console.error('Error during event registration:', error);
        res.status(500).json({ error: 'Gagal mendaftar event.' });
    }
});

// Middleware autentikasi (contoh sederhana)
function authenticateToken(req, res, next) {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    if (token == null) return res.sendStatus(401);

    jwt.verify(token, 'YOUR_SECRET_KEY', (err, user) => {
        if (err) return res.sendStatus(403);
        req.user = user; // user object dari JWT payload
        next();
    });
}