const express = require('express');
const router = express.Router();
const controller = require('./admin.controller');

router.post('/create-user', controller.createUser);
router.put('/update-user/:id', controller.updateUser);
router.delete('/delete-user/:id', controller.deleteUser);

module.exports = router;