const express = require('express');
const router = express.Router();
const controller = require('./presensi.controller');

router.post('/scan/:registrasiId', controller.presensiPeserta);
router.post('/upload-sertifikat/:registrasiId', controller.uploadSertifikat);

module.exports = router;