const express = require('express');
const router = express.Router();
const controller = require('./pembayaran.controller');

router.post('/upload-bukti/:registrasiId', controller.uploadBuktiPembayaran);

module.exports = router;